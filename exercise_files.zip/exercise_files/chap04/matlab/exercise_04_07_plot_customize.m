% exercise_04_07_plot_customize.m
% ��� 4.7�F���ʒu�΍�

close all
clear
format compact

figure(1)
set(gcf,'Position',[100 100 800 420]) 
subplot('Position',[0.15 0.15 0.775 0.775])

disp(' ')
disp('==================================================')
disp(' ��� 4.7')
disp('==================================================')

s = tf('s');

t = 0:0.001:10;

disp(' ')
disp('++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' ����Ώ� P(s) = 5/(s^2 + 2*s + 2)')
disp('++++++++++++++++++++++++++++++++++++++++++++++++++')

sysP = 5/(s^2 + 2*s + 2);

for i = 1:3
    disp(' ')
    disp('++++++++++++++++++++++++++++++++++++++++++++++++++')
    disp(' �R���g���[�� C(s)')
    disp('++++++++++++++++++++++++++++++++++++++++++++++++++')

    if i == 1
        kP = 2;
        sysC = kP

    elseif i == 2
        kP = 5;
        sysC = kP

    elseif i == 3    
        kP = 2;
        kI = 1.25;       
        sysC = (kP*s + kI)/s
    end
    
    disp(' ')
    disp('--------------------------------------------------')
    disp(' Gyr(s) = P(s)*C(s)/(1 + P(s)*C(s))')
    disp('--------------------------------------------------')
    
    sysL   = minreal(sysP*sysC);
    sysGyr = minreal(sysL/(1 + sysL))
    
    % ----- �O���t�̕`�� --------------------------------
    y = step(sysGyr,t);

    figure(1)
    plot(t,y,'LineWidth',1.5)
    hold on
end

figure(1)
hold off

set(gca,'FontName','Arial','FontSize',14)
xlabel('t [s]','FontName','Arial','FontSize',16)
ylabel('y(t)','FontName','Arial','FontSize',16)

grid on

legend({'C(s) = 2','C(s) = 5','C(s) = (2s + 1.25)/s'}, ...
        'FontName','Arial','FontSize',16)

xlim([0 10])
ylim([0 1.5])
set(gca,'XTick',0:1:10)
set(gca,'YTick',0:0.5:1.5)

movegui('north')
