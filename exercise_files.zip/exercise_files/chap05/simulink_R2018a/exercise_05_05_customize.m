% exercise_05_05_customize.m
% ��� 5.5�F�ڕW�l�����ɒ��ڂ�����Ԍn�� I-PD ����

close all
clear
format compact

disp(' ')
disp('=====================================================')
disp(' ��� 5.5�F�ڕW�l�����ɒ��ڂ�����Ԍn�� I-PD ����')
disp('=====================================================')

s = tf('s');

disp(' ')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' ����Ώ� y(s) = P(s)u(s), P(s) = 1/(M*s^2 + c*s)')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')

M = 0.440
c = 8.32

sysP = 1/(M*s^2 + c*s)

disp(' ')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' 3 ���̋K�̓��f��')
disp('                            wn^3                    ')
disp(' Gm3(s) = ------------------------------------------')
disp('          s^3 + alpha2*wm*s^2 + alpha1*wn^2*s + wn^3')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')

wm = 20
alpha1 = 3
alpha2 = 3

sysGm3 = wm^3/(s^3 + alpha2*wm*s^2 + alpha1*wm^2*s + wm^3)

disp(' ')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' �݌v���ꂽ PID �p�����[�^')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')

kI = M*wm^3
kP = M*alpha1*wm^2
kD = M*alpha2*wm - c

disp(' ')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' �R���g���[�� u(s) = C3(s)r(s) - C1(s)y(s)')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')

sysC1 = kP + kI/s + kD*s       % C1(s)
sysC3 =      kI/s              % C3(s)

disp(' ')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' Gyr(s) = P(s)*C3(s)/(1 + P(s)*C1(s))')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')

sysPC1 = minreal(sysP*sysC1);
sysPC3 = minreal(sysP*sysC3);

sysGyr = minreal(sysPC3/(1 + sysPC1))

disp(' ')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' Gyd(s) = P(s)/(1 + P(s)*C1(s))')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')

sysGyd = minreal(sysP/(1 + sysPC1))

disp(' ')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')
disp(' �ڕW�l r(t) = rc = 1')
disp(' �O���@ d(t) = dc = 0')
disp('+++++++++++++++++++++++++++++++++++++++++++++++++++++')

rc = 1
dc = 0

% ++++++++++++++++++++++++++++++++++++++++++++++++++++
% �V�~�����[�V����
% ++++++++++++++++++++++++++++++++++++++++++++++++++++
sim('exercise_05_05_i_pd_cont')

% -------------------------------------------
figure(1)
subplot('Position',[0.15 0.15 0.775 0.775])

plot(t,y,'LineWidth',1.5)
set(gca,'FontSize',14,'FontName','Arial')

xlabel('t [s]','FontSize',16,'FontName','Arial');
ylabel('y(t) = z(t) [m]','FontSize',16,'FontName','Arial')

xlim([0 1])
ylim([0 1.5])
set(gca,'XTick',0:0.2:1)
set(gca,'YTick',0:0.5:1.5)

grid on

% -------------------------------------------
figure(2)
subplot('Position',[0.15 0.15 0.775 0.775])

plot(t,u,'LineWidth',1.5)
set(gca,'FontSize',14,'FontName','Arial')

xlabel('t [s]','FontSize',16,'FontName','Arial');
ylabel('u(t) = f(t) [N]','FontSize',16,'FontName','Arial')

xlim([0 1])
ylim([-20 80])
set(gca,'XTick',0:0.2:1)
set(gca,'YTick',-20:20:80)

grid on

% -------------------------------------------
figure(1); movegui('northwest')
figure(2); movegui('northeast')


